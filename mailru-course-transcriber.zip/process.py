#!/usr/bin/env python3
"""
Скачивает видео по публичным ссылкам cloud.mail.ru и транскрибирует их через Groq API.
Рассчитан на запуск в облаке (например, в GitHub Actions) — ваш компьютер не участвует.

Вход:
  links.txt — по одной публичной ссылке cloud.mail.ru на строку.
              Можно задать своё имя файла через запятую:
                https://cloud.mail.ru/public/xxxx/yyyy/lesson1.mp4
                https://cloud.mail.ru/public/xxxx/zzzz,my_custom_name.mp4
              Строки, начинающиеся с #, игнорируются.

Выход:
  <output_dir>/<имя_файла>.txt — по одному транскрипту на ссылку.
  Уже готовые транскрипты при повторном запуске пропускаются.

ВАЖНО про скачивание:
  cloud.mail.ru не даёт официального API для гостевого скачивания по публичной
  ссылке — используется неофициальная библиотека, которая дергает внутренний
  (недокументированный) API. Mail.ru несколько раз меняли этот API, что ломало
  подобные инструменты. Если шаг скачивания перестал работать:
    1. проверьте issues репозитория библиотеки:
       https://github.com/aratakileo/mailru-cloud-guest-api-wrapper
    2. как запасной вариант — скачайте файлы вручную (или скопируйте в свой
       Google Drive/Яндекс.Диск) и положите их в папку videos/ с теми же
       именами, что в links.txt; скрипт увидит готовый файл и пропустит
       скачивание, сразу перейдя к транскрибации.
"""

import os
import sys
import time
import tempfile
import subprocess
from pathlib import Path
from urllib.parse import urlparse, unquote

import requests
from groq import Groq
from mailru_cloud_guest_api import MailruCloudFileStreamLinkGenerator

SEGMENT_SECONDS = 20 * 60          # 20 минут на кусок аудио — с запасом под лимит Groq 25MB
AUDIO_BITRATE = "32k"              # моно + 32kbps opus достаточно для разборчивой речи
MODEL = "whisper-large-v3"         # максимальное качество (WER ~8.4%); дороже и медленнее turbo
MAX_RETRIES = 3
DOWNLOAD_DIR = Path("videos")
DOWNLOAD_DELAY_SECONDS = 3         # пауза между скачиваниями, чтобы не долбить mail.ru слишком часто


def git_autocommit(path: Path):
    """Коммитит и пушит один готовый файл сразу после транскрибации.
    Если джоба упадёт по таймауту на 40-м видео из 50 — первые 39 уже
    будут сохранены в репозитории, а не потеряны."""
    if os.environ.get("GIT_AUTOCOMMIT") != "1":
        return
    try:
        subprocess.run(["git", "add", str(path)], check=True)
        if subprocess.run(["git", "diff", "--cached", "--quiet"]).returncode == 0:
            return  # нечего коммитить (файл не изменился)
        subprocess.run(["git", "commit", "-m", f"Add transcript {path.name}"], check=True)
        for attempt in range(5):
            if subprocess.run(["git", "push"]).returncode == 0:
                return
            print("    push не прошёл, пробую git pull --rebase и повтор...")
            subprocess.run(["git", "pull", "--rebase"])
            time.sleep(5)
        print(f"[!] Не удалось запушить {path.name} — сделайте git push вручную позже")
    except Exception as e:
        print(f"[!] Ошибка автокоммита для {path.name}: {e}")


def guess_filename(link: str) -> str:
    path = unquote(urlparse(link).path)
    name = path.rstrip("/").split("/")[-1]
    return name or "file.bin"


def download_link(link: str, dest_dir: Path, custom_name: str | None) -> Path:
    dest_dir.mkdir(parents=True, exist_ok=True)
    filename = custom_name or guess_filename(link)
    dest = dest_dir / filename

    if dest.exists() and dest.stat().st_size > 0:
        print(f"    уже скачан: {dest.name}")
        return dest

    gen = MailruCloudFileStreamLinkGenerator(link)
    stream_url = gen.file_stream_link
    if not stream_url:
        raise RuntimeError(
            "Не удалось получить прямую ссылку на файл — возможно, mail.ru "
            "поменял внутренний API. См. комментарий вверху файла."
        )

    with requests.get(stream_url, stream=True, timeout=120) as r:
        r.raise_for_status()
        tmp_dest = dest.with_suffix(dest.suffix + ".part")
        with open(tmp_dest, "wb") as f:
            for chunk in r.iter_content(chunk_size=1 << 20):
                f.write(chunk)
        tmp_dest.rename(dest)
    return dest


def extract_and_chunk_audio(video_path: Path, workdir: Path) -> list[Path]:
    pattern = workdir / "chunk_%04d.ogg"
    cmd = [
        "ffmpeg", "-y", "-i", str(video_path),
        "-vn", "-ac", "1", "-ar", "16000",
        "-c:a", "libopus", "-b:a", AUDIO_BITRATE,
        "-f", "segment", "-segment_time", str(SEGMENT_SECONDS),
        "-reset_timestamps", "1",
        str(pattern),
    ]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != 0:
        raise RuntimeError(f"ffmpeg упал: {result.stderr.decode(errors='ignore')[-1500:]}")
    chunks = sorted(workdir.glob("chunk_*.ogg"))
    if not chunks:
        raise RuntimeError("ffmpeg не создал ни одного аудио-куска")
    return chunks


def transcribe_chunk(client: Groq, chunk_path: Path) -> str:
    last_err = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            with open(chunk_path, "rb") as f:
                resp = client.audio.transcriptions.create(
                    file=(chunk_path.name, f.read()),
                    model=MODEL,
                    response_format="text",
                    temperature=0.0,
                )
            return str(resp).strip()
        except Exception as e:
            last_err = e
            wait = 2 ** attempt
            print(f"    попытка {attempt} не удалась ({e}); повтор через {wait}с")
            time.sleep(wait)
    raise RuntimeError(f"Не удалось транскрибировать {chunk_path.name}: {last_err}")


def parse_links_file(path: Path):
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "," in line:
            url, name = line.split(",", 1)
            yield url.strip(), name.strip()
        else:
            yield line, None


def main():
    if len(sys.argv) != 3:
        sys.exit("Использование: python process.py links.txt output_dir")

    links_file = Path(sys.argv[1])
    output_dir = Path(sys.argv[2])
    output_dir.mkdir(parents=True, exist_ok=True)

    api_key = os.environ.get("GROQ_API_KEY")
    if not api_key:
        sys.exit("Задайте переменную окружения GROQ_API_KEY")

    client = Groq(api_key=api_key)
    entries = list(parse_links_file(links_file))
    print(f"Ссылок в списке: {len(entries)}")

    for link, custom_name in entries:
        try:
            print(f"[>] {link}")
            video_path = download_link(link, DOWNLOAD_DIR, custom_name)

            out_file = output_dir / (video_path.stem + ".txt")
            if out_file.exists():
                print("    транскрипт уже есть, пропуск")
                continue

            with tempfile.TemporaryDirectory() as tmp:
                chunks = extract_and_chunk_audio(video_path, Path(tmp))
                print(f"    кусков аудио: {len(chunks)}")
                texts = [transcribe_chunk(client, c) for c in chunks]

            out_file.write_text("\n\n".join(texts), encoding="utf-8")
            print(f"[v] {out_file}")
            git_autocommit(out_file)

            # экономим место на раннере GitHub Actions
            video_path.unlink(missing_ok=True)

        except Exception as e:
            print(f"[!] Ошибка на {link}: {e}")

        time.sleep(DOWNLOAD_DELAY_SECONDS)


if __name__ == "__main__":
    main()
